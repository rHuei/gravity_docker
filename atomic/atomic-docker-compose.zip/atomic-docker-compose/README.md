mkdir /tmp/data 
git clone -b main --single-branch https://JheSue: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@github.com/JheSue/demoFlow.git /tmp/data/atomic
sudo chown -R 1001:1001 /tmp/data

然後在docker-compose up
